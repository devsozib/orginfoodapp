<?php $__env->startSection('content'); ?>

<section class="">
    <div class="container-fluid">
        <div class="block-header">
            <h2>All Order Status</h2>


        </div>
        <!-- Basic Table -->
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="header">
                        <h2>
                           All Order Status
                        </h2>
                        <?php if(auth()->user()->role == "sr"): ?>
                        <ul class="header-dropdown m-r--5">
                            <a class="btn-sm btn-primary float-right"href="<?php echo e(route('order_place')); ?>">Place Order</a>
                        </ul>
                        <?php endif; ?>

                    </div>
                    <div class="body" id="order_table">
                        <div class="table-responsive">
                            <table class="table" >
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th  scope="col">Collected Amount</th>
                                        <th scope="col">Paid Amount</th>
                                        <th  scope="col">Date</th>

                                    </tr>
                                </thead>
                                <tbody>

                                <?php $__empty_1 = true; $__currentLoopData = $paymentHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <th scope="row"><?php echo e($loop->index+1); ?></th>
                                        <td colspan="1"><?php echo e($item->collected_amount); ?></td>
                                        <td colspan="1"><?php echo e($item->paid_amount); ?></td>
                                        <td><?php echo e($item->date); ?></td>

                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <th class="text-danger text-center" colspan="8">No Payment History</th>

                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- #END# Basic Table -->

    </div>
</section>

<script type="text/javascript">

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\resources\views/order/paymentHistory.blade.php ENDPATH**/ ?>