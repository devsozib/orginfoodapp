<?php $__env->startSection('content'); ?>

<section class="">
    <div class="container-fluid">
        <div class="block-header">
            <h2> All Raw Materials Item</h2>


        </div>
        <!-- Basic Table -->
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="header">
                        <h2>
                           All Raw Materials Item

                        </h2>

                        <ul class="header-dropdown m-r--5">
                            <a class="btn-sm btn-primary float-right"href="<?php echo e(route('create_raw_materials')); ?>">Add Raw Materials Item</a>
                        </ul>


                    </div>
                    <div class="body table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Unit</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php

                                ?>
                            <?php $__currentLoopData = $raw_materials_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->index+1); ?></th>
                                    <td><?php echo e($product->name); ?></td>
                                    <td><?php echo e($product->unit); ?></td>
                                    <td><?php echo e(_('...')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- #END# Basic Table -->

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\resources\views/raw_materials_item/index.blade.php ENDPATH**/ ?>