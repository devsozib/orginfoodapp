<?php $__env->startSection('content'); ?>

<section class="">
   <!--<purchase-materials-table ></purchase-materials-table>-->


    <div class="container-fluid">
        <div class="block-header">
            <h2> All Raw product sales history</h2>
        </div>
        <!-- Basic Table -->
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="header">
                        <h2>
                           All raw product sales history
                        </h2>

                        <?php if(auth()->user()->role != 'super_admin'): ?>
                        <ul class="header-dropdown m-r--5">
                            <a class="btn-sm btn-primary float-right"href="<?php echo e(route('raw_product_sale_create')); ?>">Sale Raw Products</a>
                        </ul>
                        <?php endif; ?>

                    </div>

                    <!--<all-production></all-production>-->

                     <div class="body table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Raw Product Name</th>
                                    <th>Consumer Name</th>
                                    <?php if(auth()->user()->role == 'super_admin'): ?>
                                    <th>Branche Name</th>
                                    <?php endif; ?>
                                    <th>Qty</th>
                                    <th>Total Amount</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php

                                ?>
                            <?php $__currentLoopData = $rawProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->index+1); ?></th>
                                    <td><?php echo e($item->proName); ?></td>
                                    <td><?php echo e($item->consumerName); ?></td>
                                    <?php if(auth()->user()->role == 'super_admin'): ?>
                                     <td><?php echo e($item->branch_name); ?></td>
                                     <?php endif; ?>
                                     <td><?php echo e($item->qty); ?></td>
                                     <td><?php echo e($item->total_amount); ?></td>
                                    <td><?php echo e($item->date); ?></td>
                                    <td><?php echo e(_('...')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>


                </div>
            </div>
        </div>
        <!-- #END# Basic Table -->

    </div>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\resources\views/raw_product_sale/index.blade.php ENDPATH**/ ?>