<?php $__env->startSection('content'); ?>

<section class="">
    <div class="container-fluid">
        <div class="block-header">
            <h2> All Vendors</h2>


        </div>
        <!-- Basic Table -->
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="header">
                        <h2>
                           All Vendors

                        </h2>
                        <ul class="header-dropdown m-r--5">
                           <?php if(auth()->user()->role == "super_admin" or auth()->user()->role == "admin"): ?>
                                <a class="btn-sm btn-primary float-right"href="<?php echo e(route('create_vendors')); ?>">Add Vendor</a>
                           <?php endif; ?>
                        </ul>
                    </div>
                    <div class="body table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Branch</th>
                                    <th>Address</th>
                                    <th>Due</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $own_vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php
                                   $total_due_Amount = App\Models\VendorAccount::where('vendor_id',$vendor->id)->where('status',0)->sum('amount');

                                   $total_payment_Amount = App\Models\VendorAccount::where('vendor_id',$vendor->id)->where('status',1)->sum('amount');

                                   $nowDueIs = $total_due_Amount  - $total_payment_Amount  ;
                                //    dd( $nowDueIs );

                              ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->index+1); ?></th>
                                    <td><?php echo e($vendor->vendor_name); ?></td>
                                    <td><?php echo e($vendor->branch_name); ?></td>
                                    <td><?php echo e($vendor->address); ?></td>
                                    <td>৳<?php echo e($nowDueIs); ?></td>
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                               Action
                                              <span class="caret"></span>
                                            </button>
                                            <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                                              <li><a href="<?php echo e(route('payment_history',$vendor->id)); ?>">Payment History</a></li>
                                              <li><a href="<?php echo e(route('purchase_history',$vendor->id)); ?>">Purchase History</a></li>
                                              <?php if(auth()->user()->role == "admin"): ?>
                                              <li><a href="<?php echo e(route('due_payment',$vendor->id)); ?>">Pay</a></li>
                                              <?php endif; ?>
                                            </ul>
                                          </div>
                                    </td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- #END# Basic Table -->

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\resources\views/vendors/index.blade.php ENDPATH**/ ?>