<?php $__env->startSection('content'); ?>

<section class="">
    <div class="container-fluid">
        <div class="block-header">
            <h2> All Consumer</h2>


        </div>
        <!-- Basic Table -->
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="header">
                        <h2>
                           All Consumers

                        </h2>
                        <?php if(auth()->user()->role == 'super_admin' || auth()->user()->role == 'admin'): ?>
                            <ul class="header-dropdown m-r--5">
                                <a class="btn-sm btn-primary float-right"href="<?php echo e(route('create_consumer')); ?>">Add Consumer</a>
                            </ul>
                        <?php endif; ?>
                        <a href="<?php echo e(route('consumer-pdf')); ?>">
                            <button type="button" class="btn btn-primary">Print</button>
                        </a>
                    </div>
                    <div class="body table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>NAME</th>
                                    <?php if(auth()->user()->role == 'super_admin'): ?>
                                    <th>Branch Name</th>
                                    <?php endif; ?>
                                    <th>Address</th>
                                    <th>Phone</th>
                                    <th>Due</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>


                            <?php $__currentLoopData = $consumers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consumer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $due_amount = App\Models\ConsumerAccount::where('consumer_id',$consumer->id)->where('status',0)->sum('amount');

                                $paymentAmont = App\Models\ConsumerAccount::where('consumer_id',$consumer->id)->where('status',1)->sum('amount');
                                $dueIs = $due_amount - $paymentAmont;
                            ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->index+1); ?></th>
                                    <td><?php echo e($consumer->name); ?></td>
                                    <?php if(auth()->user()->role == "super_admin"): ?>
                                    <td><?php echo e($consumer->branch_id); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo e($consumer->address); ?></td>
                                    <td><?php echo e($consumer->phone); ?></td>
                                    <td><?php echo e($dueIs); ?></td>
                                     <td>
                                        <div class="dropdown">
                                            <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                               Action
                                              <span class="caret"></span>
                                            </button>
                                            <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                                              <li><a href="<?php echo e(route('consumer_payment_history',$consumer->id)); ?>">Payment History</a></li>
                                              <li><a href="<?php echo e(route('consumer_sales_history',$consumer->id)); ?>">Sales History</a></li>
                                              <?php if(auth()->user()->role == "admin"): ?>
                                              <li><a href="<?php echo e(route('collect_due_payment',$consumer->id)); ?>">Pay</a></li>
                                              <?php endif; ?>
                                            </ul>
                                          </div>
                                     </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- #END# Basic Table -->

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\resources\views/consumer/index.blade.php ENDPATH**/ ?>