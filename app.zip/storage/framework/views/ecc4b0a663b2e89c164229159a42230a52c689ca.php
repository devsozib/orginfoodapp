<?php $__env->startSection('content'); ?>



<section class="">
    <div class="container-fluid">
        <div class="block-header">
            <h2>
               Add Consumer
            </h2>
        </div>
        <!-- Basic Validation -->
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="header">
                        <h2>Add Consumer</h2>
                        <ul class="header-dropdown m-r--5">
                            <a class="btn-sm btn-primary float-right"href="<?php echo e(route('consumers')); ?>">All Consumer</a>
                        </ul>
                    </div>
                    <div class="body">

                        <form id="form_validation"  method="post" action="<?php echo e(route('store_consumer')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="body">
                                <div class="row clearfix">
                                    <div class="col-sm-4">
                                    <div class=" form-float">
                                        <div class="form-line">
                                            <label class="">Name</label>
                                            <input value="<?php echo e(old('name')); ?>" type="text" class="form-control" placeholder="Name" name="name" required>
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class=" form-float">
                                            <div class="form-line">
                                                <label class="">Address</label>
                                                <input type="text" <?php echo e(old('address')); ?> class="form-control" placeholder="Address" name="address">
                                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        </div>

                                        <div class="col-sm-4">
                                            <div class=" form-float">
                                                <div class="form-line">
                                                    <label class="">Phone</label>
                                                    <input type="text" <?php echo e(old('phone')); ?> class="form-control" placeholder="Phone no" name="phone">
                                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            </div>

                                </div>

                            </div>
                            <button class="btn btn-primary waves-effect" type="submit">SUBMIT</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\resources\views/consumer/create.blade.php ENDPATH**/ ?>