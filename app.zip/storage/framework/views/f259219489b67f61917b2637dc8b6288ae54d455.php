<?php $__env->startSection('content'); ?>

<section class="">
    <div class="container-fluid">
        <div class="block-header">
            <h2> Your Notification </h2>
        </div>
        <!-- Basic Table -->
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="header">
                        <h2>
                        Your Notification

                        </h2>

                        <?php if(auth()->user()->role =='sr' ): ?>
                        <ul class="header-dropdown m-r--5">
                            <a class="btn-sm btn-primary float-right"href="<?php echo e(route('request_product')); ?>">Request for product</a>
                        </ul>
                        <?php endif; ?>
                    </div>

                    <div class="body table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Product</th>
                                    <?php if(auth()->user()->role != 'admin'): ?>
                                    <th>Branch</th>
                                    <?php endif; ?>
                                    <?php if(auth()->user()->role != 'sr'): ?>
                                    <th>Sr</th>
                                    <?php endif; ?>
                                    <th>Request Quantity</th>
                                    <th>In Date</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>


                            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->index+1); ?></th>
                                    <td><?php echo e($item->product_name); ?></td>
                                    <?php if(auth()->user()->role != 'admin'): ?>
                                    <td><?php echo e($item->branch_name); ?></td>
                                    <?php endif; ?>
                                    <?php if(auth()->user()->role != 'sr'): ?>
                                    <td><?php echo e($item->sr_name); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo e($item->request_quantity); ?></td>
                                    <td><?php echo e($item->in_need_date); ?></td>
                                    <td><?php echo e($item->status?"Stock not added":""); ?></td>
                                    <?php if(auth()->user()->role != 'sr'): ?>
                                    <td><a class="btn btn-primary" href="<?php echo e(route('add_stock_for_request',$item->product_id)); ?>">Add Stcok</a></td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>



                </div>
            </div>
        </div>
        <!-- #END# Basic Table -->

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\resources\views/notification/list.blade.php ENDPATH**/ ?>