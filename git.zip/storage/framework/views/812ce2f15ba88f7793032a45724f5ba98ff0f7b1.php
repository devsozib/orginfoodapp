<?php $__env->startSection('content'); ?>

<section class="">
    <div class="container-fluid">
        <div class="block-header">
            <h2> All Users</h2>


        </div>
        <!-- Basic Table -->
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="header">
                        <h2>
                           All Users

                        </h2>
                        <ul class="header-dropdown m-r--5">
                            <a class="btn-sm btn-primary float-right"href="<?php echo e(route('create_user')); ?>">Add Users</a>
                        </ul>
                    </div>
                    <div class="body table-responsive">
                        <table class="table">
                            <?php if(session('error')): ?>
                            <div class="alert alert-danger" role="alert">
                                <p class="alert-link"><?php echo e(session('error')); ?></p>
                              </div>
                        <?php endif; ?>


                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>NAME</th>

                                    <th>EMAIL</th>
                                    <th>ROLE</th>
                                    <th>ACTION</th>
                                </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->index+1); ?></th>
                                    <td><?php echo e($user->user_name); ?></td>

                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->role); ?></td>
                                    <td class="float-left">
                                        <a class="btn btn-sm btn-info" href="<?php echo e(route('userEdit',$user->id)); ?>"> <i class="material-icons">edit_square</i>Edit</a>
                                        <a class="btn btn-sm btn-danger ml-2"> <i class="material-icons">delete</i>Delete</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- #END# Basic Table -->

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\resources\views/users/index.blade.php ENDPATH**/ ?>