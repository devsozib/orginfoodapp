<?php $__env->startSection('content'); ?>

<section class="">
    <div class="container-fluid">
        <div class="block-header">
            <h2>All Order Status</h2>


        </div>
        <!-- Basic Table -->
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="header">
                        <h2>
                           All Order Status
                        </h2>
                        <?php if(auth()->user()->role == "sr"): ?>
                        <ul class="header-dropdown m-r--5">
                            <a class="btn-sm btn-primary float-right"href="<?php echo e(route('order_place')); ?>">Place Order</a>
                        </ul>
                        <?php endif; ?>

                    </div>
                    <div class="body" id="order_table">
                        <div class="table-responsive">
                            <table class="table" >
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th  scope="col">SR</th>
                                        <th  scope="col">BRANCH</th>
                                        <th scope="col">PRODUCT</th>
                                        <th scope="col">DISTRIBUTOR</th>
                                        <?php if(auth()->user()->role != 'sr'): ?>
                                        <th scope="col">Available Qty</th>
                                        <?php endif; ?>
                                        <th scope="col">Request Qty</th>
                                        <th scope="col">Price <span style="font-size: 10px; text-style: none;">(Per Unit)</span> </th>
                                        <th scope="col">Total</th>
                                        <th scope="col">Due</th>
                                        <th scope="col">Paied</th>
                                        <th scope="col">date</th>
                                        <th scope="col">Status</th>
                                        <?php if(auth()->user()->role != 'sr'): ?>
                                        <th scope="col">Action</th>
                                        <?php endif; ?>
                                        
                                    </tr>
                                </thead>
                                <tbody>

                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($loop->index+1); ?></th>
                                        <td colspan="1"><?php echo e($item->sr_name); ?></td>
                                        <td><?php echo e($item->branch_name); ?></td>
                                        <td><?php echo e($item->product_name.'-'.$item->grade_name); ?></td>
                                        <td><?php echo e($item->distributor_name); ?></td>
                                        <?php if(auth()->user()->role != 'sr'): ?>
                                        <td><?php echo e($item->available_qty ? $item->available_qty : 0); ?></td>
                                        <?php endif; ?>
                                        <td><?php echo e($item->qty); ?></td>
                                        <td><?php echo e($item->price); ?></td>
                                        <td><?php echo e($item->qty *  $item->price); ?></td>
                                        <td><?php echo e(($item->qty *  $item->price)-$item->paid_amount); ?></td>
                                        <td><?php echo e($item->paid_amount); ?></td>
                                        <td><?php echo e($item->date); ?></td>
                                        <td>
                                            <select id="select_status<?php echo e($loop->index+1); ?>" onChange="orderStatusChange(<?php echo e($item->id); ?>, 'select_status<?php echo e($loop->index+1); ?>')" class="form-select custom-select" name="status">


                                          <?php if($item->status == "pending"): ?>
                                           <option <?php echo e($item->status == 'pending'? 'selected disabled hidden': ""); ?>>Pending</option>
                                          <?php endif; ?>



                                          <?php if((auth()->user()->role == "admin" && $item->status == "pending") or $item->status == 'accepted'): ?>
                                          <option <?php echo e($item->status == 'accepted'? 'selected disabled hidden':""); ?>  value="accepted">Accepted</option>
                                          <?php endif; ?>


                                            <?php if((auth()->user()->role == "admin" && $item->status == "pending") or $item->status == 'cancel'): ?>
                                            <option <?php echo e($item->status == 'cancel'? 'selected disabled hidden': ""); ?> value="cancel">Cancel</option>
                                            <?php endif; ?>

                                            <?php if((auth()->user()->role == "admin" && $item->status == "accepted") or $item->status == 'delivered'): ?>
                                            <option  <?php echo e($item->status == 'delivered'? 'selected disabled hidden':""); ?>  value="delivered">Delivered</option>
                                            <?php endif; ?>

                                            



                                          </select>

                                          
                                          

                                        </td>
                                        <?php if($item->status == 'delivered'): ?>
                                        <?php if(auth()->user()->role != 'sr'): ?>
                                            <td>
                                                <div class="dropdown">
                                                    <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                                       Action
                                                      <span class="caret"></span>
                                                    </button>
                                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">

                                                        <li><a href="<?php echo e(route('distributor_payment_history',$item->id)); ?>">Payment History</a></li>


                                                      
                                                      
                                                      <?php if(auth()->user()->role == "account"): ?>
                                                        <li><a href="<?php echo e(route('get_payment', $item->id)); ?>">Get Payment</a></li>
                                                      <?php endif; ?>
                                                    </ul>
                                                  </div>
                                            </td>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- #END# Basic Table -->

    </div>
</section>

<script>
function orderStatusChange(id, item_id){


    var data = document.getElementById(item_id).value;

    var url= "<?php echo e(url()->current()); ?>"
    $.get('<?php echo e(route('change-order-status')); ?>', {data:data,id:id},function(data){
        // console.log(data);
        // if(data == "Error"){
        //    document.getElementById('error_message').classList.remove('d-none');
        //    document.getElementById('error_text').innerText = "e";
        // }
         $('body').load(url);
    });



}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\resources\views/order/index.blade.php ENDPATH**/ ?>