<?php $__env->startSection('content'); ?>

<section class="">
    <div class="container-fluid">
        <div class="block-header">
            <h2>Sales History</h2>
        </div>
        <!-- Basic Table -->
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="header">
                        <h2>
                            Sales Historis of <a href=""><?php echo e($consumerName->name); ?></a>
                        </h2>
                        <ul class="header-dropdown m-r--5">
                            <a class="btn-sm btn-primary float-right"href="<?php echo e(route('raw_product_sale_create')); ?>">Sale Product</a>
                        </ul>
                    </div>
                    <div class="body table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <?php if(auth()->user()->role == 'super_admin'): ?>
                                    <th>Branch Name</th>
                                    <?php endif; ?>
                                    <th>Raw Product Name</th>
                                    <th>Product Price</th>
                                    <th>Sale Qty</th>
                                    <th>Total Price</th>
                                    <th>Sale Date</th>
                                </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $salesHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->index+1); ?></th>
                                    <?php if(auth()->user()->role == 'super_admin'): ?>
                                    <td><?php echo e($item->branch_name); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo e($item->proName); ?></td>
                                    <td><?php echo e($item->price); ?></td>
                                    <td><?php echo e($item->qty); ?></td>
                                    <td><?php echo e($item->qty*$item->price); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($item->date)->format('d M Y')); ?></td>
                                    
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- #END# Basic Table -->

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\resources\views/consumer/salesHistory.blade.php ENDPATH**/ ?>