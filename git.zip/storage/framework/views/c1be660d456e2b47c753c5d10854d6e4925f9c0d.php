<?php $__env->startSection('content'); ?>

<section class="">
    <div class="container-fluid printable">
        <div class="block-header">
            <h2>Sales History</h2>
        </div>
        <!-- Basic Table -->
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="header  d-print-none">
                        <h2 class="mb-3">All Sales History</h2><br>
                        <div class="row mt-3 d-print-none">
                            <div class="col-12 col-md-2">
                                <?php if(auth()->user()->role == 'super_admin'): ?>
                                <label for="">Branch</label>
                                <select onchange="getSRs(this.value)" class="form-select form-control" aria-label="Default select example" id="branch">
                                    <option value="" selected>All</option>
                                    <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($branch->id); ?>"><?php echo e($branch->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                                  <?php endif; ?>
                            </div>
                            <div class="col-12 col-md-2">
                                <?php if(auth()->user()->role == 'super_admin' or auth()->user()->role == 'admin'): ?>
                                    <label for="">SR</label>
                                    <select onchange="getDistributors()" class="form-select form-control" aria-label="Default select example" id="sr">

                                    </select>
                                <?php endif; ?>
                            </div>
                            <div class="col-12 col-md-2">
                                <label for="">Distributor</label>
                                <select onchange="getHistoryTable()" class="form-select form-control" aria-label="Default select example" id="distributor">


                                </select>
                            </div>
                            <div class="col-12 col-md-2">
                                <label for="">Product</label>
                                <select onchange="getHistoryTable()" class="form-select form-control" aria-label="Default select example" id="product">
                                    <option value="" selected>All</option>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($product->product_id); ?>"><?php echo e($product->product_name.'-'.$product->grade_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                            </div>
                            <div class="col-12 col-md-2">
                                <label for="">From Date</label>
                                <input onchange="getHistoryTable()" type="date" class="form-select form-control" id="from_date">
                            </div>
                            <div class="col-12 col-md-2">
                                <label for="">To Date</label>
                                <input onchange="getHistoryTable()" type="date" class="form-select form-control" id="to_date">
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="body printable" >
                        <div class="table-responsive printable" id="sales_history_table">
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- #END# Basic Table -->

    </div>
</section>
<script src="https://code.jquery.com/jquery-3.6.1.min.js" ></script>
<script type="text/javascript">

    getDistributors();
    getSRs('');

    function getSRs(id){

        $.get('<?php echo e(route('get_srs')); ?>', {branch_id:id}, function(data){
            document.getElementById('sr').innerHTML = data;
            getDistributors();
        });
    }
    function getDistributors(){
        let branch = "";
        let sr = "";

        if(document.getElementById("branch"))
            branch = document.getElementById('branch').value;
        if(document.getElementById("sr"))
            sr = document.getElementById('sr').value;

        // alert(branch+" -- "+sr);
        $.get('<?php echo e(route('get_distributors')); ?>', {branch_id:branch, sr_id:sr}, function(data){
            // alert(data);
            document.getElementById('distributor').innerHTML = data;
            getHistoryTable();
        });
    }

    function getHistoryTable(){
        let branch = "";
        let sr = "";

        if(document.getElementById("branch"))
            branch = document.getElementById('branch').value;
        if(document.getElementById("sr"))
            sr = document.getElementById('sr').value;

        distributor = document.getElementById('distributor').value;
        product = document.getElementById('product').value;
        from = document.getElementById('from_date').value;
        to = document.getElementById('to_date').value;
        // alert(from);
        $.get('<?php echo e(route('sales_history_table')); ?>', {branch:branch, sr:sr, distributor:distributor, product:product, from:from, to:to}, function(data){
            document.getElementById('sales_history_table').innerHTML = data;
        });
    }


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\resources\views/order/salesHistory.blade.php ENDPATH**/ ?>