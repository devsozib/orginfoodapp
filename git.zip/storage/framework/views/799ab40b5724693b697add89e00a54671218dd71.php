<?php $__env->startSection('content'); ?>

<section class="">
    <div class="container-fluid">
        <div class="block-header">
            <h2> All Srs</h2>


        </div>
        <!-- Basic Table -->
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="header">
                        <h2>
                           All Srs

                        </h2>
                        <ul class="header-dropdown m-r--5">
                            <a class="btn-sm btn-primary float-right"href="<?php echo e(route('create_user')); ?>">Add Sr</a>
                        </ul>
                    </div>
                    <div class="body table-responsive">
                        <table class="table">
                            <?php if(session('error')): ?>
                            <div class="alert alert-danger" role="alert">
                                <p class="alert-link"><?php echo e(session('error')); ?></p>
                              </div>
                        <?php endif; ?>


                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>NAME</th>
                                    <th>BRANCH</th>
                                    <th>EMAIL</th>
                                    <th>Phone</th>
                                    <th>ACTION</th>
                                </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $srs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->index+1); ?></th>
                                    <td><?php echo e($sr->user_name); ?></td>
                                    <td><?php echo e($sr->branch_name); ?></td>
                                    <td><?php echo e($sr->email); ?></td>
                                    <td><?php echo e($sr->phone); ?></td>
                                    <td class="float-left">
                                        <a class="btn btn-sm btn-info" href=""> <i class="material-icons">edit_square</i>Edit</a>
                                        <a class="btn btn-sm btn-danger ml-2"> <i class="material-icons">delete</i>Delete</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- #END# Basic Table -->

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\resources\views/users/srs.blade.php ENDPATH**/ ?>