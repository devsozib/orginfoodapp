<?php $__env->startSection('content'); ?>



<section class="">
    <div class="container-fluid">
        <div class="block-header">
            <h2>
               Sale raw product
            </h2>
        </div>
        <!-- Basic Validation -->
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="header">
                        <h2>Sale Raw Product</h2>
                        <ul class="header-dropdown m-r--5">
                            <a class="btn-sm btn-primary float-right"href="<?php echo e(route('materials_list')); ?>">Raw Materials sales list</a>
                        </ul>
                    </div>
                    <div class="body">

                        <form id="form_validation"  method="post" action="<?php echo e(route('raw_product_sale_store')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="body">
                                <div class="row clearfix">
                                    <div class="col-sm-4">
                                    <div class=" form-float">
                                        <div class="form-line">
                                            <label class="">Raw Product Name</label>
                                            <select class="form-control" name="raw_product_id">
                                                <option value="" disabled selected hidden>-- Please select --</option>
                                                <?php $__currentLoopData = $rawProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->proName); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>
                                        </div>
                                    </div>
                                    </div>

                                    <div class="col-sm-4">
                                        <div class="form-line">
                                            <label class="form-label">Select Customer </label>
                                            <select class="form-control" name="consumer_id">
                                                <option value="" disabled selected hidden>-- Please select --</option>
                                                <?php $__currentLoopData = $consumers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consumer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($consumer->id); ?>"><?php echo e($consumer->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>

                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class=" form-float">
                                            <div class="form-line">
                                                <label class="">Date</label>
                                                <input value="<?php echo e(old('date')); ?>" type="date" class="form-control" placeholder="Name" name="date" required>
                                                <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        </div>
                                </div>

                                <div class="row clearfix">
                                    <div class="col-sm-4">
                                    <div class=" form-float">
                                        <div class="form-line">
                                            <label class="">Quantity</label>
                                            <input min="1" value="<?php echo e(old('quantity')); ?>" type="number" class="form-control" placeholder="Quantity" name="qty" required>
                                            <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    </div>

                                        

                                            <div class="col-sm-4">
                                                <div class=" form-float">
                                                    <div class="form-line">
                                                        <label class="">Collection Payment Amount</label>
                                                        <input min="1" value="<?php echo e(old('payment_amount')); ?>" type="number" class="form-control" placeholder="Collection_amount" name="collection_amount">
                                                        <?php $__errorArgs = ['payment_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                </div>

                                </div>

                            </div>
                            <button class="btn btn-primary waves-effect" type="submit">SUBMIT</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\resources\views/raw_product_sale/create.blade.php ENDPATH**/ ?>