<div class="container-fluid d-print-none" style="display: flex; justify-content: end;">
    <div class="">
        <a href="javascript:window.print()" class="btn btn-primary"><i class="material-icons">print</i>&nbsp;&nbsp;Print</a>
        
    </div>
</div>
<table class="table" >
    <thead>
        <tr>
            <th scope="col">#</th>
                <?php if(auth()->user()->role == 'super_admin'): ?>
                    <th  scope="col">BRANCH</th>
                <?php endif; ?>
            <th scope="col">PRODUCT</th>
            <th scope="col">Qty</th>
            <th scope="col">date</th>

        </tr>
    </thead>
    <tbody>

    <?php $__currentLoopData = $stockinHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($loop->index+1); ?></th>
                <?php if(auth()->user()->role == 'super_admin'): ?>
                    <td><?php echo e($item->branch_name); ?></td>
                <?php endif; ?>

            <td><?php echo e($item->name.'-'.$item->grade_name); ?></td>
            <td><?php echo e($item->qty); ?></td>
            <td><?php echo e($item->created_at->format('d M Y')); ?></td>

        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\git\resources\views/product/purchaseHistoryTable.blade.php ENDPATH**/ ?>