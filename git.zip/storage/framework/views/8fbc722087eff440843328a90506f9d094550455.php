<?php $__env->startSection('content'); ?>

<section class="">
    <div class="container-fluid">
        <div class="block-header">
            <h2> All Distributor</h2>


        </div>
        <!-- Basic Table -->
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="header">
                        <h2>
                           All Distributor

                        </h2>
                        <?php if(auth()->user()->role == 'super_admin' or auth()->user()->role == 'sr'): ?>
                            <ul class="header-dropdown m-r--5">
                                <a class="btn-sm btn-primary float-right"href="<?php echo e(route('create_distributors')); ?>">Add Distributor</a>
                            </ul>
                        <?php endif; ?>
                    </div>
                    <div class="body table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>NAME</th>

                                    <?php if(auth()->user()->role != "sr"): ?>
                                    <th>SR</th>
                                    <?php endif; ?>

                                    <th>ADDRESS</th>
                                    <th>PHONE</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>


                            <?php $__currentLoopData = $get_distributor_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $distributor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->index+1); ?></th>
                                    <td><?php echo e($distributor->name); ?></td>
                                    <?php if(auth()->user()->role != "sr"): ?>
                                    <td><?php echo e($distributor->sr_name); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo e($distributor->address); ?></td>
                                    <td><?php echo e($distributor->phone); ?></td>
                                    <td>
                                        <div class="dropdown">
                                        <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                           Action
                                          <span class="caret"></span>
                                        </button>
                                        <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                                          
                                        </ul>
                                      </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- #END# Basic Table -->

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\resources\views/distributor/index.blade.php ENDPATH**/ ?>