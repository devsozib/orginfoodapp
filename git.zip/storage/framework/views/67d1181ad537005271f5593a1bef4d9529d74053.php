<?php
    $totalPrice = 0;
    $totalCollected = 0;
    $totalPaied = 0;
?>

<div class="container-fluid d-print-none" style="display: flex; justify-content: end;">
    <div class="">
        <a href="javascript:window.print()" class="btn btn-primary"><i class="material-icons">print</i>&nbsp;&nbsp;Print</a>
        
    </div>
</div>
<table class="table" >
    <thead class="">
        <tr>
            <th scope="col">#</th>
            <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'super_admin'): ?>
                <?php if(auth()->user()->role == 'super_admin'): ?>
                    <th  scope="col">BRANCH</th>
                <?php endif; ?>
                <th  scope="col">SR</th>
            <?php endif; ?>
            <th scope="col" >PRODUCT</th>
            <th scope="col">DISTRIBUTOR</th>
            <th scope="col">Request Qty</th>
            <th scope="col">Price <span style="font-size: 10px; text-style: none;">(Per Unit)</span> </th>
            <th scope="col">Total</th>
            <th scope="col">Due</th>
            <th scope="col">Paied</th>
            <th scope="col">date</th>

        </tr>
    </thead>
    <tbody>

    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $totalPrice += ($item->qty *  $item->price);
            $totalCollected += $item->collected_amount;
            $totalPaied += $item->paid_amount;
        ?>
        <tr>
            <th scope="row"><?php echo e($loop->index+1); ?></th>
            <?php if(auth()->user()->role == 'admin' or auth()->user()->role == 'super_admin'): ?>
                <?php if(auth()->user()->role == 'super_admin'): ?>
                    <td><?php echo e($item->branch_name); ?></td>
                <?php endif; ?>
                <td ><?php echo e($item->sr_name); ?></td>
            <?php endif; ?>

            <td><?php echo e($item->product_name.'-'.$item->grade_name); ?></td>
            <td><?php echo e($item->distributor_name); ?></td>

            <td><?php echo e($item->qty); ?></td>
            <td><?php echo e($item->price); ?></td>
            <td><?php echo e(($item->qty *  $item->price)); ?></td>
            <td><?php echo e(($item->qty *  $item->price)-$item->paid_amount); ?></td>
            <td><?php echo e($item->paid_amount); ?></td>
            <td><?php echo e($item->date); ?></td>

        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<p class="text-end" style="text-align: end;">Total Price: <?php echo e($totalPrice); ?></p>
<p class="text-end" style="text-align: end;">Total Paied: <?php echo e($totalPaied); ?></p>
<?php /**PATH C:\xampp\htdocs\git\resources\views/Order/salesHistoryTable.blade.php ENDPATH**/ ?>