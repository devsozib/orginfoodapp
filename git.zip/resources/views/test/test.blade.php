@extends('layouts.app')
@section('content')

 <div class="container">
    {{-- <vue-x></vue-x> --}}
    <file-upload></file-upload>
 </div>

@endsection
